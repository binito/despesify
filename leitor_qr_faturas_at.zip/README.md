# Leitor de QR Code de Faturas Portuguesas (AT)

Sistema para extrair e descodificar automaticamente os dados de faturas portuguesas através do código QR da Autoridade Tributária.

## 📋 O que faz

- Lê códigos QR de imagens de faturas
- Extrai automaticamente todos os dados estruturados:
  - NIF do emitente e adquirente
  - Data e número do documento
  - Código ATCUD
  - Valores base, IVA e total
  - Taxas de IVA aplicadas
  - Hash de validação
- Exporta dados para JSON
- Fácil integração com outros sistemas

## 🚀 Instalação

### No Raspberry Pi / Linux

```bash
# Instalar dependências do sistema
sudo apt-get update
sudo apt-get install -y python3-opencv libzbar0

# Instalar dependências Python
pip3 install -r requirements.txt --break-system-packages
```

### No Windows

```bash
# Instalar dependências Python
pip install -r requirements.txt
```

### No macOS

```bash
# Instalar zbar
brew install zbar

# Instalar dependências Python
pip3 install -r requirements.txt
```

## 📖 Uso Básico

### Via Linha de Comandos

```bash
# Processar uma fatura
python3 leitor_qr_faturas_at.py fatura.jpg

# Processar e guardar em JSON
python3 leitor_qr_faturas_at.py fatura.jpg --json dados.json
```

### Como Módulo Python

```python
from leitor_qr_faturas_at import LeitorQRFaturaAT

# Criar instância do leitor
leitor = LeitorQRFaturaAT()

# Processar fatura
fatura = leitor.processar_fatura('caminho/para/fatura.jpg')

# Aceder aos dados
if fatura:
    print(f"NIF: {fatura['nif_emitente']}")
    print(f"Total: {fatura['valor_total']}€")
    print(f"Data: {fatura['data_emissao']}")
    
    # Ver dados de IVA
    for linha_iva in fatura['linhas_iva']:
        print(f"Base: {linha_iva['base_tributavel']}€")
        print(f"IVA: {linha_iva['valor_iva']}€")
        print(f"Taxa: {linha_iva['taxa_iva_codigo']}")
```

## 🔧 Exemplos de Integração

Consulta o ficheiro `exemplo_integracao.py` para ver exemplos de como integrar com:

1. **Processar faturas em lote** - processar todas as faturas de uma pasta
2. **Exportar para Excel** - criar tabela com todas as faturas
3. **Validação automática** - validar e categorizar por fornecedor
4. **Sistema de contabilidade** - preparar dados para contabilidade
5. **Monitorização automática** - processar automaticamente novas faturas
6. **API REST** - criar endpoint web para processar faturas
7. **Descodificação direta** - se já tens o texto do QR

## 📊 Estrutura dos Dados Extraídos

```json
{
  "nif_emitente": "123456789",
  "nif_adquirente": "987654321",
  "pais_adquirente": "PT",
  "tipo_documento": "FT",
  "estado_documento": "N",
  "data_emissao": "2024-11-20",
  "numero_documento": "FT 2024/123",
  "atcud": "ATCUD123-456",
  "linhas_iva": [
    {
      "pais": "PT",
      "base_tributavel": 100.0,
      "valor_iva": 23.0,
      "taxa_iva_codigo": "NOR",
      "taxa_iva_percentagem": 23
    }
  ],
  "valor_total": 123.0,
  "retencao_iva": 0,
  "hash": "ABC123...",
  "numero_certificado": "1234"
}
```

## 🎯 Casos de Uso para o Café Martins

### 1. Arquivo Digital de Faturas de Fornecedores

```python
# Processar todas as faturas dos fornecedores
leitor = LeitorQRFaturaAT()
faturas = leitor.processar_lote_faturas('./faturas_fornecedores')

# Guardar em Excel para controlo
df = pd.DataFrame(faturas)
df.to_excel('controlo_fornecedores_2024.xlsx')
```

### 2. Validação Automática de Faturas

```python
# Verificar se a fatura está correcta
fatura = leitor.processar_fatura('nova_fatura.jpg')

# Comparar com encomenda
if fatura['valor_total'] != valor_esperado:
    print("⚠️ Valor não corresponde à encomenda!")
```

### 3. Categorização de Despesas

```python
# Categorizar automaticamente por NIF do fornecedor
categorias = {
    'NIF_FORNECEDOR_BEBIDAS': 'Bebidas',
    'NIF_FORNECEDOR_CAFE': 'Café',
    'NIF_ENERGIA': 'Serviços',
}

categoria = categorias.get(fatura['nif_emitente'], 'Outros')
```

### 4. Preparação para Contabilista

```python
# Extrair dados e preparar ficheiro para contabilista
dados_contabilidade = []

for fatura_img in faturas_mes:
    fatura = leitor.processar_fatura(fatura_img)
    dados_contabilidade.append({
        'Data': fatura['data_emissao'],
        'Fornecedor': fatura['nif_emitente'],
        'Documento': fatura['numero_documento'],
        'Base': fatura['linhas_iva'][0]['base_tributavel'],
        'IVA': fatura['linhas_iva'][0]['valor_iva'],
        'Total': fatura['valor_total']
    })

# Enviar Excel para contabilista
pd.DataFrame(dados_contabilidade).to_excel('faturas_marco_2024.xlsx')
```

## ❓ Resolução de Problemas

### "Nenhum código QR encontrado"

- Verifica se a imagem tem boa qualidade
- Certifica-te que o QR está visível e não cortado
- Tenta aumentar a resolução da imagem

### Erro ao instalar pyzbar

No Linux/Raspberry Pi:
```bash
sudo apt-get install libzbar0
```

No macOS:
```bash
brew install zbar
```

### Valores estranhos ou incorrectos

- O formato do QR pode variar ligeiramente entre emissores
- Verifica os dados brutos em `fatura['raw_data']`
- Contacta-me se precisares ajustar o parser

## 📝 Notas Importantes

- ✅ Funciona com faturas portuguesas que tenham QR code da AT
- ✅ Extrai dados estruturados automaticamente
- ✅ Muito mais rápido e preciso que OCR tradicional
- ⚠️ Requer que o QR esteja visível e legível na imagem
- ⚠️ Não extrai dados de itens individuais (só totais)

## 🔄 Integração com Outros Sistemas

O script é facilmente integrável com:

- ✅ Sistemas de contabilidade (exporta para Excel/JSON)
- ✅ Bases de dados (SQLite, MySQL, PostgreSQL)
- ✅ Aplicações web (via API REST)
- ✅ Sistemas de arquivo digital
- ✅ Automação de processos (cron jobs, monitorização de pastas)
- ✅ WhatsApp Bot (enviar alertas de faturas)
- ✅ Google Sheets (via API)

## 📞 Suporte

Se precisares de ajuda para integrar ou adaptar o código:
- Verifica os exemplos em `exemplo_integracao.py`
- Consulta a documentação inline no código
- Testa com faturas reais do Café Martins

## 🎓 Para Aprender Mais

Este código usa:
- **OpenCV** - processamento de imagens
- **pyzbar** - leitura de códigos QR e códigos de barras
- **JSON** - estruturação e exportação de dados

Conceitos úteis para aprender:
- Processamento de imagens
- Leitura de QR codes
- Automação de processos
- APIs REST
