"""
Exemplo de como integrar o LeitorQRFaturaAT noutros processos
"""

from leitor_qr_faturas_at import LeitorQRFaturaAT
import os
from datetime import datetime


# EXEMPLO 1: Processar uma única fatura
def exemplo_processar_fatura_simples():
    """Exemplo básico de processar uma fatura"""
    leitor = LeitorQRFaturaAT()
    
    # Processar a fatura
    fatura = leitor.processar_fatura('fatura_exemplo.jpg')
    
    if fatura:
        # Aceder aos dados extraídos
        print(f"NIF Fornecedor: {fatura['nif_emitente']}")
        print(f"Valor Total: {fatura['valor_total']}€")
        print(f"Data: {fatura['data_emissao']}")
        
        # Usar os dados como precisares
        return fatura
    else:
        print("Erro ao processar fatura")
        return None


# EXEMPLO 2: Processar múltiplas faturas em lote
def exemplo_processar_lote_faturas(pasta_faturas: str):
    """Processa todas as faturas numa pasta"""
    leitor = LeitorQRFaturaAT()
    faturas_processadas = []
    
    # Percorrer todos os ficheiros na pasta
    for ficheiro in os.listdir(pasta_faturas):
        if ficheiro.lower().endswith(('.jpg', '.jpeg', '.png', '.pdf')):
            caminho_completo = os.path.join(pasta_faturas, ficheiro)
            
            print(f"\nA processar: {ficheiro}")
            fatura = leitor.processar_fatura(caminho_completo)
            
            if fatura and 'erro' not in fatura:
                faturas_processadas.append({
                    'ficheiro': ficheiro,
                    'dados': fatura
                })
    
    return faturas_processadas


# EXEMPLO 3: Integrar com base de dados ou Excel
def exemplo_guardar_em_excel(pasta_faturas: str, ficheiro_saida: str):
    """Processa faturas e guarda em Excel"""
    import pandas as pd
    
    leitor = LeitorQRFaturaAT()
    dados_para_excel = []
    
    for ficheiro in os.listdir(pasta_faturas):
        if ficheiro.lower().endswith(('.jpg', '.jpeg', '.png')):
            caminho_completo = os.path.join(pasta_faturas, ficheiro)
            fatura = leitor.processar_fatura(caminho_completo)
            
            if fatura and 'erro' not in fatura:
                # Criar linha para o Excel
                linha = {
                    'Ficheiro': ficheiro,
                    'NIF_Emitente': fatura['nif_emitente'],
                    'NIF_Adquirente': fatura['nif_adquirente'],
                    'Data': fatura['data_emissao'],
                    'Numero_Doc': fatura['numero_documento'],
                    'Valor_Total': fatura['valor_total'],
                    'ATCUD': fatura['atcud']
                }
                
                # Adicionar informação de IVA (primeira linha)
                if fatura['linhas_iva']:
                    linha['Base_Tributavel'] = fatura['linhas_iva'][0].get('base_tributavel')
                    linha['Valor_IVA'] = fatura['linhas_iva'][0].get('valor_iva')
                    linha['Taxa_IVA'] = fatura['linhas_iva'][0].get('taxa_iva_codigo')
                
                dados_para_excel.append(linha)
    
    # Criar DataFrame e guardar
    df = pd.DataFrame(dados_para_excel)
    df.to_excel(ficheiro_saida, index=False)
    print(f"\nDados guardados em: {ficheiro_saida}")
    
    return df


# EXEMPLO 4: Validar e categorizar faturas
def exemplo_validar_e_categorizar(caminho_fatura: str):
    """Valida a fatura e categoriza por tipo de fornecedor"""
    leitor = LeitorQRFaturaAT()
    fatura = leitor.processar_fatura(caminho_fatura)
    
    if not fatura or 'erro' in fatura:
        return {'valida': False, 'motivo': 'QR não legível'}
    
    resultado = {
        'valida': True,
        'nif_fornecedor': fatura['nif_emitente'],
        'valor': fatura['valor_total'],
        'data': fatura['data_emissao'],
        'categoria': None
    }
    
    # Exemplo: Categorizar por NIF (podes adaptar para os teus fornecedores)
    nif = fatura['nif_emitente']
    
    # Adiciona aqui a lógica de categorização dos teus fornecedores
    categorias_fornecedores = {
        '123456789': 'Bebidas',
        '987654321': 'Alimentação',
        '555666777': 'Limpeza',
        # etc...
    }
    
    resultado['categoria'] = categorias_fornecedores.get(nif, 'Outros')
    
    return resultado


# EXEMPLO 5: Integrar com sistema de contabilidade
def exemplo_preparar_para_contabilidade(caminho_fatura: str):
    """Prepara dados da fatura para sistema de contabilidade"""
    leitor = LeitorQRFaturaAT()
    fatura = leitor.processar_fatura(caminho_fatura)
    
    if not fatura or 'erro' in fatura:
        return None
    
    # Formato para sistema de contabilidade
    registo_contabilidade = {
        'tipo_documento': 'Fatura de Fornecedor',
        'numero_documento': fatura['numero_documento'],
        'data_documento': fatura['data_emissao'],
        'nif_fornecedor': fatura['nif_emitente'],
        'valor_base': sum(linha.get('base_tributavel', 0) for linha in fatura['linhas_iva']),
        'valor_iva': sum(linha.get('valor_iva', 0) for linha in fatura['linhas_iva']),
        'valor_total': fatura['valor_total'],
        'atcud': fatura['atcud'],
        'linhas_iva': []
    }
    
    # Detalhar linhas de IVA para contabilidade
    for linha_iva in fatura['linhas_iva']:
        registo_contabilidade['linhas_iva'].append({
            'base': linha_iva.get('base_tributavel', 0),
            'iva': linha_iva.get('valor_iva', 0),
            'taxa': linha_iva.get('taxa_iva_percentagem', 0),
            'taxa_codigo': linha_iva.get('taxa_iva_codigo', 'NOR')
        })
    
    return registo_contabilidade


# EXEMPLO 6: Usar apenas o descodificador (se já tens o texto do QR)
def exemplo_descodificar_qr_direto():
    """Se já tens a string do QR code, podes descodificar diretamente"""
    leitor = LeitorQRFaturaAT()
    
    # Exemplo de string QR (substitui pela tua)
    dados_qr = "A:123456789*B:987654321*C:PT*D:FT*E:N*F:20241120*G:FT 2024/123*H:ATCUD123-123*I1:PT*I2:100.00*I3:23.00*I4:NOR*N:123.00*O:0*P:HASH123*Q:1234"
    
    fatura = leitor.descodificar_qr_fatura(dados_qr)
    return fatura


# EXEMPLO 7: Monitorizar pasta e processar automaticamente
def exemplo_monitorizar_pasta_faturas(pasta_monitorizar: str, pasta_processadas: str):
    """
    Monitoriza uma pasta e processa automaticamente novas faturas
    Útil para integrar com sistema de scanning automático
    """
    import time
    import shutil
    
    leitor = LeitorQRFaturaAT()
    ficheiros_processados = set()
    
    print(f"A monitorizar pasta: {pasta_monitorizar}")
    
    while True:
        # Verificar novos ficheiros
        for ficheiro in os.listdir(pasta_monitorizar):
            if ficheiro.lower().endswith(('.jpg', '.jpeg', '.png')):
                caminho_completo = os.path.join(pasta_monitorizar, ficheiro)
                
                # Se não foi processado ainda
                if ficheiro not in ficheiros_processados:
                    print(f"\nNova fatura detectada: {ficheiro}")
                    
                    fatura = leitor.processar_fatura(caminho_completo)
                    
                    if fatura and 'erro' not in fatura:
                        # Guardar dados em JSON
                        nome_json = ficheiro.rsplit('.', 1)[0] + '.json'
                        leitor.exportar_json(fatura, os.path.join(pasta_processadas, nome_json))
                        
                        # Mover imagem para pasta de processadas
                        shutil.move(caminho_completo, os.path.join(pasta_processadas, ficheiro))
                        
                        ficheiros_processados.add(ficheiro)
                        
                        print(f"✓ Fatura processada e arquivada")
                    else:
                        print(f"✗ Erro ao processar {ficheiro}")
        
        # Esperar 5 segundos antes de verificar novamente
        time.sleep(5)


# EXEMPLO 8: API REST simples (com Flask)
def exemplo_criar_api_rest():
    """
    Exemplo de como criar uma API REST para processar faturas
    Útil se quiseres integrar com aplicações web ou móveis
    """
    from flask import Flask, request, jsonify
    import base64
    import io
    from PIL import Image
    
    app = Flask(__name__)
    leitor = LeitorQRFaturaAT()
    
    @app.route('/processar_fatura', methods=['POST'])
    def processar_fatura_endpoint():
        """Endpoint para processar fatura via API"""
        try:
            # Receber imagem em base64
            dados = request.json
            imagem_base64 = dados.get('imagem')
            
            if not imagem_base64:
                return jsonify({'erro': 'Imagem não fornecida'}), 400
            
            # Decodificar e guardar temporariamente
            imagem_bytes = base64.b64decode(imagem_base64)
            imagem = Image.open(io.BytesIO(imagem_bytes))
            
            caminho_temp = '/tmp/fatura_temp.jpg'
            imagem.save(caminho_temp)
            
            # Processar
            fatura = leitor.processar_fatura(caminho_temp)
            
            if fatura and 'erro' not in fatura:
                return jsonify(fatura), 200
            else:
                return jsonify({'erro': 'Não foi possível processar a fatura'}), 422
                
        except Exception as e:
            return jsonify({'erro': str(e)}), 500
    
    # Para executar: app.run(host='0.0.0.0', port=5000)
    return app


if __name__ == "__main__":
    print("Exemplos de integração do Leitor QR Faturas AT")
    print("=" * 60)
    print("\nEscolhe um exemplo para executar:")
    print("1. Processar fatura simples")
    print("2. Processar lote de faturas")
    print("3. Guardar em Excel")
    print("4. Validar e categorizar")
    print("5. Preparar para contabilidade")
    print("6. Descodificar QR direto")
    print("7. Monitorizar pasta")
    print("8. Criar API REST")
    
    # Podes descomentar e testar os exemplos que precisares
    # exemplo_processar_fatura_simples()
    # exemplo_processar_lote_faturas('./faturas')
    # etc...
